from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    number = None
    text = ""
    
    if request.method == 'POST':
        num_str = request.form.get('user_number')
        if num_str:
            try:
                num = float(num_str)
                result = num * 2
                number = result
                text = f"Ваше число {num}, умноженное на 2: {result}"
            except ValueError:
                text = "Пожалуйста, введите корректное число."
    
    return render_template('index.html', number=number, text=text)

if __name__ == '__main__':
    app.run(debug=True)