from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def circle_area():
    r = None
    pi = 3.14
    text = ""
    
    if request.method == 'POST':
        r_str = request.form.get('radius')
        if r_str:
            try:
                r = float(r_str)
                area = pi * (r ** 2)
                text = f"Площадь круга с радиусом {r} равна {area}"
            except ValueError:
                text = "Пожалуйста, введите корректное число."
    
    return render_template('index.html', r=r, pi=pi, text=text)

if __name__ == '__main__':
    app.run(debug=True)