from flask import Flask, render_template
from urllib.parse import unquote

app = Flask(__name__)

@app.route('/<path:url_path>')
def calculator(url_path):
    clean_path = unquote(url_path.strip('/'))
    parts = clean_path.split('/')
    
    if len(parts) == 3:
        try:
            num1 = float(parts[0])
            op = parts[1]
            num2 = float(parts[2])
            return render_template('index.html', num1=num1, op=op, num2=num2)
        except ValueError:
            pass
            
    return "Ошибка", 400

@app.route('/median/<int:a>/<int:b>/<int:c>/')
@app.route('/median/<int:a>/<int:b>/<int:c>')
def median(a, b, c):
    return render_template('index.html', a=a, b=b, c=c)

if __name__ == '__main__':
    app.run(debug=True)