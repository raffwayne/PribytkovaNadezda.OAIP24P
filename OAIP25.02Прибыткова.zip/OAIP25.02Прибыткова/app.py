from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user_login = request.form.get('login')
        user_password = request.form.get('password')

        if user_login == 'admin' and user_password == '1234':
            return render_template('success.html')
        else:
            return "Неверный логин или пароль! <a href='/'>Попробовать снова</a>"
    
    return render_template('login.html')

@app.route('/me')
def me():
    return render_template('index.html', name="Надя Прибыткова")

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    app.run(debug=True)